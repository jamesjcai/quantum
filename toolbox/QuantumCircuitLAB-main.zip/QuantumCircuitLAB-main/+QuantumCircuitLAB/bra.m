function output = bra(varargin)
% By bernwo on Github. Link: https://github.com/bernwo/
    output = QuantumCircuitLAB.ket(varargin{:})';
end